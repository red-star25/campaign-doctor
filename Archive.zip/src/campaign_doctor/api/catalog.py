"""Allow-list of synthetic scenario files.

The id in the URL is never used as a path. Display name and problem category
live here. The event description is read from the scenario file.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from campaign_doctor.models import Scenario, load_scenario


@dataclass(frozen=True)
class ScenarioEntry:
    scenario_id: str
    name: str
    problem_category: str
    filename: str


# One row per file we are willing to serve. Add a row when a new synthetic
# file is checked in. Do not accept a filename from the request.
_ENTRIES: tuple[ScenarioEntry, ...] = (
    ScenarioEntry(
        scenario_id="delayed_reply",
        name="Delayed reply notification",
        problem_category="delayed_reply",
        filename="delayed_reply.json",
    ),
)


class ScenarioNotFound(Exception):
    """The id is not in the allow-list."""


@dataclass(frozen=True)
class LoadedScenario:
    entry: ScenarioEntry
    scenario: Scenario


def list_entries() -> tuple[ScenarioEntry, ...]:
    return _ENTRIES


def load_entry(scenario_id: str) -> LoadedScenario:
    entry = _find(scenario_id)
    if entry is None:
        raise ScenarioNotFound()
    scenario = load_scenario(_scenario_file(entry.filename))
    return LoadedScenario(entry=entry, scenario=scenario)


def _find(scenario_id: str) -> ScenarioEntry | None:
    for entry in _ENTRIES:
        if entry.scenario_id == scenario_id:
            return entry
    return None


def _scenario_file(filename: str) -> Path:
    directory = Path(__file__).resolve().parents[3] / "scenarios"
    path = directory / filename
    if not path.is_file():
        raise ScenarioNotFound()
    return path
