"""FastAPI app. Routes call the existing engine and do not send email."""

from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from campaign_doctor.api.catalog import ScenarioNotFound
from campaign_doctor.api.schemas import (
    CompareRequest,
    CompareResponse,
    HealthResponse,
    ReportResponse,
    ScenarioListResponse,
)
from campaign_doctor.api.service import (
    UnknownFollowUp,
    build_scenario_report,
    compare_scenario,
    health,
    list_scenarios,
)

_LOCAL_ORIGIN = "http://localhost:3000"


def create_app() -> FastAPI:
    app = FastAPI(
        title="Cardinal Campaign Doctor",
        version="0.1.0",
        summary="Synthetic campaign replay API.",
        description=(
            "Reads made-up campaign logs and explains them. "
            "It does not send email and it is not connected to Cardinal."
        ),
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[_LOCAL_ORIGIN],
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
    )

    @app.get("/api/health", response_model=HealthResponse)
    def get_health() -> HealthResponse:
        return health()

    @app.get("/api/scenarios", response_model=ScenarioListResponse)
    def get_scenarios() -> ScenarioListResponse:
        return list_scenarios()

    @app.get("/api/scenarios/{scenario_id}/report", response_model=ReportResponse)
    def get_report(scenario_id: str) -> ReportResponse:
        try:
            return build_scenario_report(scenario_id)
        except ScenarioNotFound:
            raise HTTPException(status_code=404, detail="Unknown scenario.") from None

    @app.post("/api/scenarios/{scenario_id}/compare", response_model=CompareResponse)
    def post_compare(scenario_id: str, body: CompareRequest) -> CompareResponse:
        try:
            return compare_scenario(scenario_id, body.provider_condition, body.followup_event_id)
        except ScenarioNotFound:
            raise HTTPException(status_code=404, detail="Unknown scenario.") from None
        except UnknownFollowUp:
            raise HTTPException(status_code=422, detail="Unknown follow-up event.") from None

    return app


app = create_app()
